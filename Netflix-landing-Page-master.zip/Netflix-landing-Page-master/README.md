# Netflix-landing-Page
![Landing Page](https://i.ibb.co/wQQyBTV/lp-2.png)

### [Live Site](https://codegrammer-netflix-landing-page-real.netlify.app)

## Introduction

In this code repository, i have created Netflix Landing Page. I have used HTML5 , CSS3 & Javascript in this to make it responsive.

By creating this landing Page,i have gained a strong understanding of what Landing Page is and how you can build, deploy and publish it to web.

Setup:
- run ```Localhost:3000``` or ```Index.html``` On your Local Machine.

## License 

[MIT](https://github.com/web-codegrammer/Netflix-landing-Page/blob/master/LICENSE)

Issued to ```Devanshu Vashishtha``` | All Rights Reserved | 2020
 
